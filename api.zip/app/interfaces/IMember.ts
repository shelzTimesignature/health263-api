// eslint-disable-next-line @typescript-eslint/naming-convention
export interface IMember {
  MedicalSchemeNumber?: string
  MedicalSchemeName?: string
}
