// eslint-disable-next-line @typescript-eslint/naming-convention
export interface IProvider {
  Role?: string
  PracticeNumber?: string
  PracticeName?: string
}
