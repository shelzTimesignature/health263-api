
export interface IDiagnosis {
  Code: string
}
