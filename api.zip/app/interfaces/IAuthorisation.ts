// eslint-disable-next-line @typescript-eslint/naming-convention
export interface IAuthorisation {
  PreAuthorisationNumber: string
  AuthorisationNumber: string
  AuthorisationDate: string
}
