export interface ITotalValues {
  GrossAmount: number
  NettAmount: number
}
