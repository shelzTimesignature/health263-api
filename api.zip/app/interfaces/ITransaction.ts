export interface ITransaction {
  Type?: string
  Number?: string
  DestinationCode?: string
  DateTime?: string
}
