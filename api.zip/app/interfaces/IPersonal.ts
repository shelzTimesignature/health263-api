
export interface IPersonal {
  Title?: string
  Surname?: string
  FirstName?: string
  Initials?: string
  Gender?: string
  DateOfBirth?: string

}
